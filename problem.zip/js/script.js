


$(document).ready(function () {
    // 메인메뉴 기능
    let popup = $('.popup')
    let header = $('.header')


    $(window).scroll(function () {
        let temp = $(window).scrollTop();
        if (temp > 0) {
            popup.addClass('popup-close')
            header.addClass('header-show')
        } else {
            popup.removeClass('popup-close')
            header.removeClass('header-show')
        }
    })
    $(document).ready(function () {
        // 팝업닫기
        let pop = $('.popup');
        let pop_close = $('.popup-close-btn');
        pop_close.click(function (event) {
            // a 태그의 href 로 이동하는 기능 막기
            event.preventDefault();

            pop.hide();
        });
    });

    let header_right_logo = $('.header-right-logor')
    let mb_wrap_close = $('.mb-wrap-top-icon2');

    header_right_logo.click(onClickNavbar);
    mb_wrap_close.click(onClickNavbar);

    function onClickNavbar(event) {
        event.preventDefault();
        let mb_wrap = $('.mb-wrap')

        mb_wrap.removeClass('mb-wrap-close')
        mb_wrap.toggleClass('mb-wrap-open')
    }
});



window.onload = function () {
    new Swiper('.sw-events', {
        loop: true,
        // navigation: {
        //     nextEl: ".swiper-button-next",
        //     prevEl: ".swiper-button-prev",
        // },
        autoplay: {
            delay: 2500,
            disableOnInteraction: false,
        },
        pagination: {
            el: '.sw-events-control-main',
            type: 'fraction',
            // clickable: true,
        },
        navigation: {
            prevEl: '.sw-events-prev',
            nextEl: '.sw-events-next'
        },
    });

    // 출력 할 데이터 목록

    let itemsData = [{
            link: '#',
            pic: 'items1.png',
            title : '초신선 돼지 삼겹살 구이용',
            desc : '기준가 23,400원/600g'
        },
        {
            link: '#',
            pic: 'items2.png',
            title : '초신선 닭볶음탕',
            desc : '기준가 6,700원/950g'
        },
        {
            link: '#',
            pic: 'items3.png',
            title : '초신선 등심 돈까스',
            desc : '기준가 11,800원/770g'
        },
        {
            link: '#',
            pic: 'items4.png',
            title : '초신선 동물복지 무항생제 유정란',
            desc : '기준가 6,900원/12구'
        },
        {
            link: '#',
            pic: 'items5.png',
            title : '초신선 무항생제 우유',
            desc : '기준가 3,600원/900ml'
        },
        {
            link: '#',
            pic: 'items6.png',
            title : '초신선 무항생제 이유식용 한우 우둔 다짐육',
            desc : '기준가 15,300원/180g'
        }];
        console.log(itemsData)

    function showItemsInfo(_tag, _data){
        let who = $(_tag);
        console.log(who);

        who.attr('href', _data.link); 

        let showHtml = `
        <div class="items-img-case">
            <a href="#" class="items-pic"></a>
            <a href="#" class="items-bt"></a>
        </div>
        <h3 class="items-title">${_data.title}</h3>
        <p class="items-desc">${_data.desc}</p>
        `;

        who.html(showHtml);

        let itemBg = who.find('.items-pic');
        console.log(itemBg);
        itemBg.css('background', 'url(images/' + _data.pic + ') no-repeat center');
        itemBg.css('background-size', '276px 276px');
    };

    showItemsInfo('#item-list-1', itemsData[0]);
    showItemsInfo('#item-list-2', itemsData[1]);
    showItemsInfo('#item-list-3', itemsData[2]);
    showItemsInfo('#item-list-4', itemsData[3]);
    showItemsInfo('#item-list-5', itemsData[4]);
    showItemsInfo('#item-list-6', itemsData[5]);
};


// // 제품의 데이터 링크 목록
// let goodLink = [];

// // 제품의 이미지 목록
// let goodPic = [];

// // 제품의 타이틀 목록
// let goodTitle = [];

// // 제품의 가격 목록
// let goodPrice = [];

// // 제품의 옵션 1 링크 목록
// let goodOption1 = [];

// // 제품의 옵션 2 링크 목록
// let goodOption2 = [];


// // 객체를 이용한 제품 목록

// let goodList = [
//     {}

// ];